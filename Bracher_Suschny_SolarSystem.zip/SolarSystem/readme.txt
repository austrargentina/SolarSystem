-To start the programm, go to Sources -> MVC and run "StartScreen".

-To show the documentation, go to doc -> html and open index.html.

-To look up the controls, use the user's guide.

Have fun!